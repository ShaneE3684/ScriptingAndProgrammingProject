//Shane Esplin_Scripting and Programming-Applications
//rodter.h file