//Shane Esplin_Scripting and Programming-Applications
//degree.h file

enum DegreeProgram{SECURITY, NETWORK, SOFTWARE}