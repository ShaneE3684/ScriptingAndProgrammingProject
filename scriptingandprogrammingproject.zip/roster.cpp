//Shane Esplin_Scripting and Programming-Applications
//roster.cpp file

#include <roster.h>
#include <iostream>