//Shane Esplin_Scripting and Programming-Applications
//student.cpp file

#include <student.h>
#include <iostream>